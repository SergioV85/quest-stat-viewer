[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=SergioV85_quest-stat-viewer&metric=alert_status)](https://sonarcloud.io/dashboard?id=SergioV85_quest-stat-viewer)

# Quest Statistic Viewer App

## Installation
1. Clone repository
2. Run `npm i`
3a. Run `npm run start` to run the app with local server
3b. Compile the project using the command `npm run build` and after that run `npm run start:heroku` to lun locally with external server

